package com.loadafrica.load_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
